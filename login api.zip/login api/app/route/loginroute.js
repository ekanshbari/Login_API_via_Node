'use strict';
module.exports = function(app) {
  var UserController = require('../controller/loginController.js');

    // app.route('/login')
    // .post(UserController.create_user)
    // .get(UserController.list_all_users);

    app.route('/loginUser/:username/:password')
    .get(UserController.validate_a_user);
   };